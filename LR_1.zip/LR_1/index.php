<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="img/Снимок экрана 2022-09-18 230550.png" type="image/x-icon">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/style.css">
    <title>ПРОИЗВОДСТВО МЕТАЛЛОКОНСТРУКЦИЙ - ЗАВОД ДОНПАНЕЛЬМЕТАЛЛ</title>
</head>
<body>
    <div class="visible-lg visible-md title-v">
        <header class="header_6">
            <div class="container text-center">
                <div class="row align-items-center">
                    <div class="with-padding col-md-5">
                        <div class="search-block">
                            <div class="search-wrapper">
                                <div class="title-search_fixed">
                                    <form action="/search/" class="search">
                                        <div class="search-input-div">
                                            <input class="search-input" id="title-search-input_fixed" type="text" name="q" value 
                                            placeholder="Найти" size="40" maxlength="50" autocomplete="off">
                                            <button class="search-btn">
                                                <img src="https://cdn4.iconfinder.com/data/icons/ionicons/512/icon-ios7-search-strong-256.png" alt="">
                                            </button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="logo-block col-md-2 col-sm-2">
                        <div class="log">
                            <a href="/"><img src="img/sdsdsd.png" width="80" height="80" alt="ЗАВОД ДОНПАНЕЛЬМЕТАЛЛ" title="ЗАВОД ДОНПАНЕЛЬМЕТАЛЛ"></a>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="rigth-icons">
                            <div class="phone-block with_btn pull-right">
                                <div class="inner-table-block p-block">
                                    <div class="phone with_dropdown big">
                                        <i class="svg inline svg-inline-phone colored" aria-hidden="true">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 14 14">
                                                <path class="pcls-1" d="M14,11.052a0.5,0.5,0,0,0-.03-0.209,1.758,1.758,0,0,0-.756-0.527C12.65,10,12.073,9.69,11.515,9.363a2.047,2.047,0,0,0-.886-0.457c-0.607,0-1.493,1.8-2.031,1.8a2.138,2.138,0,0,1-.856-0.388A9.894,9.894,0,0,1,3.672,6.253,2.134,2.134,0,0,1,3.283,5.4c0-.536,1.8-1.421,1.8-2.027a2.045,2.045,0,0,0-.458-0.885C4.3,1.932,3.99,1.355,3.672.789A1.755,1.755,0,0,0,3.144.034,0.5,0.5,0,0,0,2.935,0,4.427,4.427,0,0,0,1.551.312,2.62,2.62,0,0,0,.5,1.524,3.789,3.789,0,0,0-.011,3.372a7.644,7.644,0,0,0,.687,2.6A9.291,9.291,0,0,0,1.5,7.714a16.783,16.783,0,0,0,4.778,4.769,9.283,9.283,0,0,0,1.742.825,7.673,7.673,0,0,0,2.608.686,3.805,3.805,0,0,0,1.851-.507,2.62,2.62,0,0,0,1.214-1.052A4.418,4.418,0,0,0,14,11.052Z"/>
                                            </svg>
                                        </i>
                                        <a href="tel:+78632098451" class="zphone" > 8(863)209-84-51 </a>
                                    </div>
                                    <div class="schedule fw-lighter fs-6">
                                        <p class="special-header-p-1">Пн. – Пт.: с 9:00 до 18:00</p>
                                        <p class="special-header-p-2">Прием заказов без выходных</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="rigth-icons">
                            <div class="phone-block with_btn pull-right">
                                <div class="inner-table-block table-block-custom">
                                    <span class="callback-block animate-load colored  btn-transparent-bg btn-default btn border border-primary" 
                                    data-event="jqm" data-param-id="63" data-name="callback">Заказать звонок</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <nav class="navbar navbar-expand-lg navbar-light navbar-custom">
                            <div class="container-fluid">
                            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
                                <span class="navbar-toggler-icon"></span>
                            </button>
                            <div class="collapse navbar-collapse" id="navbarNavDropdown">
                                <ul class="navbar-nav nav-centered">
                                <li class="nav-item bgc">
                                    <a class="nav-link" href="/services/sendvich-paneli/">СЭНДВИЧ ПАНЕЛИ</a>
                                </li>
                                <li class="nav-item bgc active">
                                    <a class="nav-link active" href="/services/metallokonstrukcii/">МЕТАЛЛОКОНСТРУКЦИИ</a>
                                </li>
                                <li class="nav-item bgc">
                                    <a class="nav-link" href="/services/bystrovozvodimye-zdaniya/">БЫСТРОВОЗВОДИМЫЕ ЗДАНИЯ</a>
                                </li>
                                <li class="nav-item bgc">
                                    <a class="nav-link" href="/services/proektirovanie/">ПРОЕКТИРОВАНИЕ</a>
                                </li>
                                <li class="nav-item bgc">
                                    <a class="nav-link" href="/contacts/">КОНТАКТЫ</a>
                                </li>
                                <li class="nav-item dropdown bgc">
                                    <a class="nav-link dropdown-toggle" href="/company/" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                        О КОМПАНИИ
                                    </a>
                                    <ul class="dropdown-menu">
                                    <li><a class="dropdown-item" href="/company/index.php">О нас</a></li>
                                    <li><hr class="dropdown-divider"></li>
                                    <li><a class="dropdown-item" href="/company/staff/">Наша команда</a></li>
                                    <li><hr class="dropdown-divider"></li>
                                    <li><a class="dropdown-item" href="/company/reviews/">Отзывы</a></li>
                                    <li><hr class="dropdown-divider"></li>
                                    <li><a class="dropdown-item" href="/company/clients/">Наши клиенты</a></li>
                                    <li><hr class="dropdown-divider"></li>
                                    <li><a class="dropdown-item" href="/company/vacancy/">Вакансии</a></li>
                                    <li><hr class="dropdown-divider"></li>
                                    <li><a class="dropdown-item" href="/company/faq/">Вопросы и ответы</a></li>
                                    <li><hr class="dropdown-divider"></li>
                                    <li><a class="dropdown-item" href="/company/rewards/">Награды и сертификаты</a></li>
                                    </ul>
                                </li>
                                </ul>
                            </div>
                            </div>
                        </nav>
                    </div>
                </div>
            </div>
        </header>
    </div>
    <section class="banner size-banner-h">
        <div class="banner-content">
            <div class="maxwidth-banner" style="background: url(img/top-bnr.jpg) 50% 50% no-repeat;">
                <div class="container">
                    <div class="row banner-s">
                        <div class="col-md-6 text animated delay06 duration08 item_block fadeInUp">
                            <h1 class="shares">ПРОИЗВОДСТВО МЕТАЛЛОКОНСТРУКЦИЙ</h1>
                            <div class="intro-text">
                                <div>
                                    <p>
                                        Завод "ДонПанельМеталл" выпускает металлоконструкции любой сложности. Мощность производства более 600 т/мес.</p>
                                </div>
                            </div>
                            <div class="buttons">
                                <button type="button" class="btn bgc" data-bs-toggle="modal" data-bs-target="#staticBackdrop">
                                    Получить консультацию
                                </button>
                                <div class="modal fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                                    <div class="modal-dialog modal-dialog-scrollable">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                        <h5 class="modal-title" id="staticBackdropLabel">Заказать услугу</h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                        </div>
                                        <div class="modal-body">
                                            <form class="row g-3 needs-validation" novalidate>
                                                <div class="mb-5">
                                                    <label for="inputUser4" class="form-label">Ваше имя:</label>
                                                    <input type="user" class="form-control" id="inputUser4" required>
                                                    <span class="icon-inside"><i class="fa fa-user-o" aria-hidden="true"></i></span>
                                                    <div class="invalid-feedback">Заполните поле</div>
                                                </div>
                                                
                                                <div class="mb-5">
                                                    <label for="inputPhone4" class="form-label">Телефон:</label>
                                                    <input type="phone" class="form-control" id="inputPhone4" required>
                                                    <span class="icon-inside"><i class="fa fa-phone" aria-hidden="true"></i></span>
                                                    <div class="invalid-feedback">Заполните поле</div>
                                                </div>

                                                <div class="mb-5">
                                                    <label for="inputEmail4" class="form-label">E-mail:</label>
                                                    <input type="email" class="form-control" id="inputEmail4">
                                                    <span class="icon-inside"><i class="fa fa-envelope" aria-hidden="true"></i></span>
                                                </div>
                                                
                                                <div class="input-group mb-5">
                                                    <select class="form-select" aria-label="Default select example">
                                                        <option selected>Услуга:</option>
                                                        <option value="1">ПРОИЗВОДСТВО МЕТАЛЛОКОНСТРУКЦИЙ</option>
                                                    </select>
                                                </div>
                                                
                                                <div class="mb-5">
                                                    <label for="inputMassage4" class="form-label">Сообщение:</label>
                                                    <textarea class="form-control" id="inputMassage4" rows="1"></textarea>
                                                </div>
                                                
                                                <div class="mb-5">
                                                    <label for="inputCode4" class="form-label">Введите код:</label>
                                                    <div class="row g-2">
                                                        <div class="col-md">
                                                        <div class="form-floating">
                                                            <input type="inputCode4" class="form-control" id="floatingInputGrid" placeholder="????" value="????">
                                                            <label for="floatingInputGrid">????</label>
                                                        </div>
                                                        </div>
                                                        <div class="col-md">
                                                        <div class="form-floating">
                                                            <input type="inputCode4" class="form-control" id="inputCode4" required>
                                                            <div class="invalid-feedback">Заполните поле</div>
                                                        </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault" required>
                                                    <label class="form-check-label" for="flexCheckDefault">
                                                        Я согласен на 
                                                        <a href="/include/licenses_detail.php" target="_blank">обработку персональных данных</a>
                                                    </label>
                                                    <div class="invalid-feedback">Солгалитесь с условиями</div>
                                                </div>
                                                <button class="btn btn-primary" type="submit">Отправить</button>
                                            </form>
                                        </div>
                                    </div>
                                    </div>
                                </div>
                                <button type="button" class="btn btn bcc" data-bs-toggle="modal" data-bs-target="#staticBackdrop">
                                    Задать вопрос
                                </button>
                                <div class="modal fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                                    <div class="modal-dialog modal-dialog-scrollable">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                        <h5 class="modal-title" id="staticBackdropLabel">Задать вопрос</h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                        </div>
                                        <div class="modal-body">
                                            <form class="row g-3 needs-validation" novalidate>
                                                <div class="mb-5">
                                                    <label for="inputUser4" class="form-label">Ваше имя:</label>
                                                    <input type="user" class="form-control" id="inputUser4" required>
                                                    <span class="icon-inside"><i class="fa fa-user-o" aria-hidden="true"></i></span>
                                                    <div class="invalid-feedback">Заполните поле</div>
                                                </div>
                                                
                                                <div class="mb-5">
                                                    <label for="inputPhone4" class="form-label">Телефон:</label>
                                                    <input type="phone" class="form-control" id="inputPhone4" required>
                                                    <span class="icon-inside"><i class="fa fa-phone" aria-hidden="true"></i></span>
                                                    <div class="invalid-feedback">Заполните поле</div>
                                                </div>

                                                <div class="mb-5">
                                                    <label for="inputEmail4" class="form-label">E-mail:</label>
                                                    <input type="email" class="form-control" id="inputEmail4">
                                                    <span class="icon-inside"><i class="fa fa-envelope" aria-hidden="true"></i></span>
                                                </div>
                                                
                                                <div class="input-group mb-5">
                                                    <select class="form-select" aria-label="Default select example">
                                                        <option selected>Услуга:</option>
                                                        <option value="1">ПРОИЗВОДСТВО МЕТАЛЛОКОНСТРУКЦИЙ</option>
                                                    </select>
                                                </div>
                                                
                                                <div class="mb-5">
                                                    <label for="inputMassage4" class="form-label">Сообщение:</label>
                                                    <textarea class="form-control" id="inputMassage4" rows="1"></textarea>
                                                </div>
                                                
                                                <div class="mb-5">
                                                    <label for="inputCode4" class="form-label">Введите код:</label>
                                                    <div class="row g-2">
                                                        <div class="col-md">
                                                        <div class="form-floating">
                                                            <input type="inputCode4" class="form-control" id="floatingInputGrid" placeholder="????" value="????">
                                                            <label for="floatingInputGrid">????</label>
                                                        </div>
                                                        </div>
                                                        <div class="col-md">
                                                        <div class="form-floating">
                                                            <input type="inputCode4" class="form-control" id="inputCode4" required>
                                                            <div class="invalid-feedback">Заполните поле</div>
                                                        </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault" required>
                                                    <label class="form-check-label" for="flexCheckDefault">
                                                        Я согласен на 
                                                        <a href="/include/licenses_detail.php" target="_blank">обработку персональных данных</a>
                                                    </label>
                                                    <div class="invalid-feedback">Солгалитесь с условиями</div>
                                                </div>
                                                <button class="btn btn-primary" type="submit">Отправить</button>
                                            </form>
                                        </div>
                                    </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 hidden-xs hidden-sm img animated delay09 duration08 item_block fadeInUp">
                            <div class="inner">
                                <img src="https://sk-donpanel.ru/upload/iblock/88b/metall1.JPG" width="690" height="450" alt="ПРОИЗВОДСТВО МЕТАЛЛОКОНСТРУКЦИЙ" title="ПРОИЗВОДСТВО МЕТАЛЛОКОНСТРУКЦИЙ">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section>
        <div class="container twosect">
            <div class="row">
                <div class="col-3">
                    <div class="accordion" id="accordionPanelsStayOpenExample">
                        <div class="accordion-item">
                        <h2 class="accordion-header" id="panelsStayOpen-headingOne">
                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#panelsStayOpen-collapseOne" aria-expanded="false" aria-controls="panelsStayOpen-collapseOne">
                                СЭНДВИЧ ПАНЕЛИ
                            </button>
                        </h2>
                        <div id="panelsStayOpen-collapseOne" class="accordion-collapse collapse" aria-labelledby="panelsStayOpen-headingOne">
                            <div class="submenu-wrapper hidden-block" style="display: block;">
                                <ul class="submenu">
                                    <li class="li-accordion"><a class="dropdown-item" href="/services/sendvich-paneli/stenovie-sendvich-paneli/">СТЕНОВЫЕ СЭНДВИЧ ПАНЕЛИ</a></li>
                                    <li class="li-accordion"><a class="dropdown-item" href="/services/sendvich-paneli/krovelnye-paneli/">КРОВЕЛЬНЫЕ ПАНЕЛИ</a></li>
                                    <li class="li-accordion"><a class="dropdown-item" href="/services/sendvich-paneli/fasonnye-elementy/">ФАСОННЫЕ ЭЛЕМЕНТЫ</a></li>
                                </ul>
                            </div>
                        </div>
                        </div>
                        <div class="accordion-item">
                        <h2 class="accordion-header" id="panelsStayOpen-headingTwo">
                            <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#panelsStayOpen-collapseTwo" aria-expanded="true" aria-controls="panelsStayOpen-collapseTwo">
                                МЕТАЛЛОКОНСТРУКЦИИ
                            </button>
                        </h2>
                        <div id="panelsStayOpen-collapseTwo" class="accordion-collapse collapse show" aria-labelledby="panelsStayOpen-headingTwo">
                            <div class="submenu-wrapper hidden-block" style="display: block;">
                                <ul class="submenu">
                                    <li class="li-accordion"><a class="dropdown-item" href="/services/metallokonstrukcii/proizvodstvo-stroitelnykh-metallokonstrukcij/">ПРОИЗВОДСТВО<wbr>МЕТАЛЛОКОНСТРУКЦИЙ</a></li>
                                </ul>
                            </div>
                        </div>
                        </div>
                        <div class="accordion-item">
                        <h2 class="accordion-header" id="panelsStayOpen-headingThree">
                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#panelsStayOpen-collapseThree" aria-expanded="false" aria-controls="panelsStayOpen-collapseThree">
                                БЫСТРОВОЗВОДИМЫЕ ЗДАНИЯ
                            </button>
                        </h2>
                        <div id="panelsStayOpen-collapseThree" class="accordion-collapse collapse" aria-labelledby="panelsStayOpen-headingThree">
                            <div class="submenu-wrapper hidden-block" style="display: block;">
                                <ul class="submenu">
                                    <li class="li-accordion"><a class="dropdown-item" href="/services/bystrovozvodimye-zdaniya/bistrovozvodimie_zdaniya1/">Быстровозводимые здания</a></li>
                                    <li class="li-accordion"><a class="dropdown-item" href="/services/bystrovozvodimye-zdaniya/modulnye-zdaniya/">Модульные здания</a></li>
                                </ul>
                            </div>
                        </div>
                        </div>
                        <div class="accordion-item">
                            <h2 class="accordion-header" id="panelsStayOpen-headingFour">
                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#panelsStayOpen-collapseFour" aria-expanded="false" aria-controls="panelsStayOpen-collapseFour">
                                ПРОЕКТИРОВАНИЕ
                            </button>
                            </h2>
                            <div id="panelsStayOpen-collapseFour" class="accordion-collapse collapse" aria-labelledby="panelsStayOpen-headingFour">
                                <div class="submenu-wrapper hidden-block" style="display: block;">
                                    <ul class="submenu">
                                        <li class="li-accordion"><a class="dropdown-item" href="/services/proektirovanie/proektno-konstruktorskaya-deyatelnost/">ПРОЕКТНО-КОНСТРУКТОРСКАЯ<wbr>ДЕЯТЕЛЬНОСТЬ</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="sidearea">
                        <div class="ask_a_question border">
                            <div class="inner staff_inner">
                                <div class="staff_question">
                                    <div class="image">
                                        <a href="/company/staff/tushev-andrey-leonidovich/">
                                            <img class="image-sotrydnik" src="img/Tushev-A.L.q.jpg" alt="Тушев Андрей Леонидович" title="Тушев Андрей Леонидович">
                                        </a>
                                    </div>
                                    <div class="top-block">
                                        <div class="name">
                                            <a href="/company/staff/tushev-andrey-leonidovich/" class="dark-color fs-5 fw-light text-wrap">Тушев Андрей Леонидович</a>
                                        </div>
                                        <div class="post fw-lighter fs-6">Инженер - конструктор</div>
                                    </div>
                                    <div class="staff_text">
                                        <p>
                                            С радостью отвечу на любые
                                            <br>
                                            ваши вопросы по проекту
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <div class="outer">
                                <span class="btn btn-default btn-transparent-bg animate-load border border-primary" data-event="jqm" data-param-id="67" data-autoload-staff="Ту
                                шев Андрей Леонидович" data-autoload-need_product="ПРОИЗВОДСТВО МЕТАЛЛОКОНСТРУКЦИЙ" data-name="question"><span>Задать вопрос</span></span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-9">
                    <ul class="nav nav-tabs">
                        <li class="nav-item">
                          <a class="nav-link padd-nav-link active" aria-current="page" href="#pane1">Описание</a>
                        </li>
                        <li class="nav-item">
                          <a class="nav-link padd-nav-link" href="#">Вопрос/ответ</a>
                        </li>
                    </ul>
                      <div class="tab-content">
                          <div id="pane1" class="tab-pane active">
                                <p class="margin-top-text">Завод "ДонПанельМеталл" выпускает металлоконструкции любой сложности. Мощность производства более 600 т/мес.
                                Цехи оснащены системой очистки воздуха, инфракрасным отоплением, малярным оборудованием.</p>
                                <h3 class="margin-h fw-normal fs-4">В единую систему компьютерного управления объединены:</h3>
                                <ul class="margin-ul">
                                    <li class="li-style">Роботизированный комплекс обработки металла VOORTMAN.</li>
                                </ul>
                                <p class="margin-p">Изготовление сварной балки высотой до 2-х метров, шириной до 1 метра, балки переменного сечения. 
                                    Распил металлопроката под любым углом, сверление одновременно в трёх плоскостях.</p>
                                <ul class="margin-ul">
                                    <li class="li-style">Установка портальной резки с газовыми горелками и плазмой.</li>
                                </ul>
                                <p>Обработка листов толщиной до 150 мм, изготовление заготовок любой формы.</p>
                                    <p class="special-p">Программируемая установка для сверления деталей.</p>
                                <p>Сверление отверстий диаметром до 40 мм в листе толщиной до 60 мм</p>
                                <ul class="margin-ul">
                                    <li class="li-style">Дробемётная установка.</li>
                                </ul>
                                <p>Подготовка поверхности под нанесение грунтовки, лакокрасочного покрытия.</p>
                                <p>Все работы контролируются инспектором ОТК и выполняются в соответствии со всеми требованиями ГОСТа</p>
                          </div>
                      </div>
                    <div class="row gen-boss-info">
                        <div class="col-md-12">
                            <h5 class="sotrudnik-h fs-3 fw-light">Сотрудник</h5>
                            <div class="gen-boss border-top border-bottom">
                                <div class="row">
                                    <div class="col-md-3">
                                        <div class="image">
                                            <a href="/company/staff/pyotr-trikoz/">
                                                <img class="image-boss" width="150" height="150" src="img/WhatsApp-Image-2020_01_27-at-09.55.09.jpeg" alt="Пётр Трикоз" title="Пётр Трикоз">
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-md-9 align-items-left">
                                        <div class="name-boss">
                                            <a href="/company/staff/tushev-andrey-leonidovich/" class="dark-color fs-4 fw-light text-wrap">Пётр Трикоз</a>
                                        </div>
                                        <div class="post-boss fw-lighter fs-6">Генеральный директор</div>
                                        <div class="phone-boss">
                                            <img width="13" alt="lorem" src="http://sk-donpanel.ru/111_files/tlf.png" height="18" style="margin-bottom: -3px;">
                                            <a href="tel:+7 (919) 877-39-76" class="zphone-boss" >  8(938)121-00-27 </a>
                                        </div>
                                        <div class="email-boss">
                                            <img width="13" alt="lorem" src="http://sk-donpanel.ru/111_files/eml.png" height="15" style="margin-bottom: -3px;">
                                            <a href class="zphone-boss" >  zavod.dpm@yandex.ru </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row border">
                        <div class="col-md-9 col-sm-8 col-xs-7 valign">
                            <div class="row">
                                <div class="col-md-2 col-sm-3 col-xs-4">
                                    <div class="text-down">
                                        <i class="svg inline  svg-inline-order colored" aria-hidden="true"><svg width="48" height="60" viewBox="0 0 48 60">
                                            <path class="form_project_cls_1" d="M48,3406h0v-1H42v1h0a1,1,0,0,0,1,1h4A1,1,0,0,0,48,3406Zm2-9.94a13.768,13.768,0,0,1-10,0V3399h5a1,1,0,1,1,0,2H40v1h0a1,1,0,0,0,1,1h8a1,1,0,0,0,1-1v-5.94Z" transform="translate(-21 -3357)"></path>
                                            <path d="M50.77,3385.7c-0.864,1.27-3.141,2.23-4.77,2.77V3391a1,1,0,0,1-2,0v-2.53c-1.629-.54-3.905-1.5-4.77-2.77-1.567-2.31-1.193-7.7-1.193-7.7s5.136,0.83,6.963,3.06c1.827-2.23,6.963-3.06,6.963-3.06S52.337,3383.39,50.77,3385.7Zm-7.2-3.3c-0.681-1.2-3.324-2.2-3.324-2.2s-0.156,2.69.5,3.85c0.587,1.04,2.739,1.65,2.739,1.65S44.114,3383.37,43.565,3382.4Zm6.193-2.2s-2.642,1-3.324,2.2c-0.549.97,0.087,3.3,0.087,3.3s2.151-.61,2.738-1.65C49.914,3382.89,49.758,3380.2,49.758,3380.2ZM21,3417v-60H60l9,9v51H21Zm39-57.43V3366h6.357Zm7,8.43H58v-9H23v56H44v-6H43a3,3,0,0,1-3-3h0v-1h1a3,3,0,0,1-3-3h0v-6.89a14,14,0,1,1,14,0V3402h0a3,3,0,0,1-3,3h1v1a3,3,0,0,1-3,3H46v6H67v-47Zm-19,38h0v-1H42v1h0a1,1,0,0,0,1,1h4A1,1,0,0,0,48,3406Zm2-9.94a13.768,13.768,0,0,1-10,0V3399h5a1,1,0,1,1,0,2H40v1h0a1,1,0,0,0,1,1h8a1,1,0,0,0,1-1v-5.94ZM57,3383a12,12,0,1,0-12,12A12,12,0,0,0,57,3383Z" transform="translate(-21 -3357)"></path>
                                        </svg>
                                        </i>
                                    </div>
                                </div>
                                <div class="col-md-10 col-sm-9 col-xs-8">
                                    <div class="inner-text">
                                        <p>Мы свяжемся с вами в ближайшее время, ответим на все интересующие вопросы.</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3 col-sm-4 col-xs-5 valign">
                            <div class="btns">
                                <span class="btn btn-default animate-load btn-info" data-event="jqm" data-param-id="60" data-name="order_services" data-autoload-service="ПРОИЗВОДСТВО МЕТАЛЛОКОНСТРУКЦИЙ" 
                                data-autoload-study="ПРОИЗВОДСТВО МЕТАЛЛОКОНСТРУКЦИЙ" data-autoload-project="ПРОИЗВОДСТВО МЕТАЛЛОКОНСТРУКЦИЙ"><span>Получить консультацию</span></span>
                            </div>
                        </div>
                    </div>
                    <div class="row strelka_nazad">
                        <div class="col-md-6 col-sm-6 col_strelka">
                            <a class="back-url url-block border" href="/services/metallokonstrukcii/">
                                <span class="strelka border-end"><</span>
                                <span class="strelka_text">Назад к списку</span>
                            </a>
                        </div>
                        <div class="col-md-6 col-sm-6 share">
                            <div class="d-flex justify-content-end">
                                <div class="back-url url-block border social_media_icons">
                                    <div class="hidden_panel">
                                        <span>
                                            <a href="https://vk.com/share.php?url=https%3A%2F%2Fsk-donpanel.ru%2Fservices%2Fmetallokonstrukcii%2Fproizvodstvo-stroitelnykh-metallokonstrukcij%2F&title=%D0%9F%D0%A0%D0%9E%D0%98%D0%97%D0%92%D0%9E%D0%94%D0%A1%D0%A2%D0%92%D0%9E%20%D0%9C%D0%95%D0%A2%D0%90%D0%9B%D0%9B%D0%9E%D0%9A%D0%9E%D0%9D%D0%A1%D0%A2%D0%A0%D0%A3%D0%9A%D0%A6%D0%98%D0%99%20-%20%D0%97%D0%90%D0%92%D0%9E%D0%94%20%D0%94%D0%9E%D0%9D%D0%9F%D0%90%D0%9D%D0%95%D0%9B%D0%AC%D0%9C%D0%95%D0%A2%D0%90%D0%9B%D0%9B&utm_source=share2">
                                                <img src="img/vkontakte.png" alt="vkontakte" class="social_media">
                                            </a>
                                        </span>
                                        <span>
                                            <a href="https://twitter.com/intent/tweet?text=%D0%9F%D0%A0%D0%9E%D0%98%D0%97%D0%92%D0%9E%D0%94%D0%A1%D0%A2%D0%92%D0%9E%20%D0%9C%D0%95%D0%A2%D0%90%D0%9B%D0%9B%D0%9E%D0%9A%D0%9E%D0%9D%D0%A1%D0%A2%D0%A0%D0%A3%D0%9A%D0%A6%D0%98%D0%99%20-%20%D0%97%D0%90%D0%92%D0%9E%D0%94%20%D0%94%D0%9E%D0%9D%D0%9F%D0%90%D0%9D%D0%95%D0%9B%D0%AC%D0%9C%D0%95%D0%A2%D0%90%D0%9B%D0%9B&url=https%3A%2F%2Fsk-donpanel.ru%2Fservices%2Fmetallokonstrukcii%2Fproizvodstvo-stroitelnykh-metallokonstrukcij%2F&utm_source=share2">
                                                <img src="img/twitter.png" alt="twitter" class="social_media">
                                            </a>
                                        </span>
                                        <span>
                                            <a href="viber://forward?text=%D0%9F%D0%A0%D0%9E%D0%98%D0%97%D0%92%D0%9E%D0%94%D0%A1%D0%A2%D0%92%D0%9E%20%D0%9C%D0%95%D0%A2%D0%90%D0%9B%D0%9B%D0%9E%D0%9A%D0%9E%D0%9D%D0%A1%D0%A2%D0%A0%D0%A3%D0%9A%D0%A6%D0%98%D0%99%20-%20%D0%97%D0%90%D0%92%D0%9E%D0%94%20%D0%94%D0%9E%D0%9D%D0%9F%D0%90%D0%9D%D0%95%D0%9B%D0%AC%D0%9C%D0%95%D0%A2%D0%90%D0%9B%D0%9B%20https%3A%2F%2Fsk-donpanel.ru%2Fservices%2Fmetallokonstrukcii%2Fproizvodstvo-stroitelnykh-metallokonstrukcij%2F&utm_source=share2">
                                                <img src="img/viber.png" alt="viber" class="social_media">
                                            </a>
                                        </span>
                                        <span>
                                            <a href="https://api.whatsapp.com/send?text=%D0%9F%D0%A0%D0%9E%D0%98%D0%97%D0%92%D0%9E%D0%94%D0%A1%D0%A2%D0%92%D0%9E%20%D0%9C%D0%95%D0%A2%D0%90%D0%9B%D0%9B%D0%9E%D0%9A%D0%9E%D0%9D%D0%A1%D0%A2%D0%A0%D0%A3%D0%9A%D0%A6%D0%98%D0%99%20-%20%D0%97%D0%90%D0%92%D0%9E%D0%94%20%D0%94%D0%9E%D0%9D%D0%9F%D0%90%D0%9D%D0%95%D0%9B%D0%AC%D0%9C%D0%95%D0%A2%D0%90%D0%9B%D0%9B%20https%3A%2F%2Fsk-donpanel.ru%2Fservices%2Fmetallokonstrukcii%2Fproizvodstvo-stroitelnykh-metallokonstrukcij%2F&utm_source=share2">
                                                <img src="img/whatsapp.png" alt="whatsapp" class="social_media">
                                            </a>
                                        </span>
                                        <span>
                                            <a href="https://connect.ok.ru/offer?url=https%3A%2F%2Fsk-donpanel.ru%2Fservices%2Fmetallokonstrukcii%2Fproizvodstvo-stroitelnykh-metallokonstrukcij%2F&title=%D0%9F%D0%A0%D0%9E%D0%98%D0%97%D0%92%D0%9E%D0%94%D0%A1%D0%A2%D0%92%D0%9E%20%D0%9C%D0%95%D0%A2%D0%90%D0%9B%D0%9B%D0%9E%D0%9A%D0%9E%D0%9D%D0%A1%D0%A2%D0%A0%D0%A3%D0%9A%D0%A6%D0%98%D0%99%20-%20%D0%97%D0%90%D0%92%D0%9E%D0%94%20%D0%94%D0%9E%D0%9D%D0%9F%D0%90%D0%9D%D0%95%D0%9B%D0%AC%D0%9C%D0%95%D0%A2%D0%90%D0%9B%D0%9B&utm_source=share2">
                                                <img src="img/odnoklassniki.png" alt="odnoklassniki" class="social_media">
                                            </a>
                                        </span>
                                        <span>
                                            <a href="https://connect.mail.ru/share?url=https%3A%2F%2Fsk-donpanel.ru%2Fservices%2Fmetallokonstrukcii%2Fproizvodstvo-stroitelnykh-metallokonstrukcij%2F&title=%D0%9F%D0%A0%D0%9E%D0%98%D0%97%D0%92%D0%9E%D0%94%D0%A1%D0%A2%D0%92%D0%9E%20%D0%9C%D0%95%D0%A2%D0%90%D0%9B%D0%9B%D0%9E%D0%9A%D0%9E%D0%9D%D0%A1%D0%A2%D0%A0%D0%A3%D0%9A%D0%A6%D0%98%D0%99%20-%20%D0%97%D0%90%D0%92%D0%9E%D0%94%20%D0%94%D0%9E%D0%9D%D0%9F%D0%90%D0%9D%D0%95%D0%9B%D0%AC%D0%9C%D0%95%D0%A2%D0%90%D0%9B%D0%9B&utm_source=share2">
                                                <img src="img/email.png" alt="email" class="social_media">
                                            </a>
                                        </span>
                                        <span class="podelitsya_icon">
                                            <img width="13" alt="lorem" src="img/share.png" height="15">
                                        </span>
                                    </div>
                                    <div class="visible_panel">
                                        <span class="podelitsya">Поделиться</span>
                                        <span class="podelitsya_icon border-start">
                                            <img width="13" alt="lorem" src="img/share.png" height="15">
                                        </span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <footer id="footer" class="ext_view">
        <div class="container">
            <div class="row bottom-middle">
                <div class="col-md-7">
                    <div class="row">
                        <div class="col-md-4 col-sm-4">
                            <div class="bottom-menu">
                                <div class="items">
                                    <div class="item-link">
                                        <div class="item">
                                            <div class="title_h">
                                                <a class="title fw-bold" href="/company/">Компания</a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="wrap">
                                        <div class="item-link">
                                            <div class="item">
                                                <div class="title">
                                                    <a class="title_s" href="/company/index.php">О нас</a>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="item-link">
                                            <div class="item">
                                                <div class="title">
                                                    <a class="title_s" href="/company/staff/">Наша команда</a>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="item-link">
                                            <div class="item">
                                                <div class="title">
                                                    <a class="title_s" href="/company/reviews/">Отзывы</a>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="item-link">
                                            <div class="item">
                                                <div class="title">
                                                    <a class="title_s" href="/company/clients/">Наши клиенты</a>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="item-link">
                                            <div class="item">
                                                <div class="title">
                                                    <a class="title_s" href="/company/vacancy/">Вакансии</a>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="item-link">
                                            <div class="item">
                                                <div class="title">
                                                    <a class="title_s" href="/company/faq/">Вопросы и ответы</a>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="item-link">
                                            <div class="item">
                                                <div class="title">
                                                    <a class="title_s" href="/company/rewards/">Награды и сертификаты</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4 col-sm-4">
                            <div class="bottom-menu">
                                <div class="items">
                                    <div class="item-link">
                                        <div class="item active">
                                            <div class="title_h">
                                                <a class="title fw-bold" href="/services/">Услуги</a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="wrap">
                                        <div class="item-link">
                                            <div class="item">
                                                <div class="title">
                                                    <a class="title_s" href="/services/sendvich-paneli/">СЭНДВИЧ ПАНЕЛИ</a>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="item-link">
                                            <div class="item">
                                                <div class="title">
                                                    <a class="title_s active" href="/services/metallokonstrukcii/">МЕТАЛЛОКОНСТРУКЦИИ</a>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="item-link">
                                            <div class="item">
                                                <div class="title">
                                                    <a class="title_s" href="/services/bystrovozvodimye-zdaniya/">БЫСТРОВОЗВОДИМЫЕ ЗДАНИЯ</a>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="item-link">
                                            <div class="item">
                                                <div class="title">
                                                    <a class="title_s" href="/services/proektirovanie/">ПРОЕКТИРОВАНИЕ</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4 col-sm-4">
                            <div class="bottom-menu">
                                <div class="items">
                                    <div class="item-link">
                                        <div class="item active">
                                            <div class="title_hd fw-bold">
                                                <span>Информация</span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="wrap">
                                        <div class="item-link">
                                            <div class="item">
                                                <div class="title">
                                                    <a class="title_s" href="/projects/">Выполненные проекты</a>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="item-link">
                                            <div class="item active">
                                                <div class="title">
                                                    <a class="title_s" href="/info/news/">Новости</a>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="item-link">
                                            <div class="item">
                                                <div class="title">
                                                    <a class="title_s" href="/include/licenses_detail.php?clear_cache=Y">Соглашение на обработку персональных данных</a>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="item-link">
                                            <div class="item">
                                                <div class="title">
                                                    <a class="title_s" href="/contacts/">Контакты</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-5">
                    <div class="row">
                        <div class="col-lg-6 col-md-12 col-sm-6">
                            <div class="soc-block">
                                <div class="subscribe-edit">
                                    <div class="title_hd fw-bold">Будьте всегда в курсе</div>
                                    <div class="input-group mb-3">
                                        <input type="text" class="form-control" placeholder="E-mail" aria-label="E-mail" aria-describedby="button-addon2">
                                        <button class="btn btn-outline-secondary" title="Подписаться" type="button" id="button-addon2">➜</button>
                                      </div>
                                </div>
                                <div class="social-block rounded_block">
                                    <div class="social-icons">
                                        <div class="title_hd fw-bold">Оставайтесь на связи</div>
                                        <div class="icons_f_i">
                                            <a href="https://www.facebook.com/sendvichrostov/?eid=ARAv1eH5UstglB7vjuGJt8RmzokHZgdI-K-d4Ht5qmQW3LWokBrJoMUvSra-v94amkeeAvBmKjwnfQuu" class="facebook" target="_blank" rel="nofollow" title="Facebook">
                                                <img src="img/facebook.png" width="40" height="40" alt="Facebook">
                                            </a>
                                            <a href="https://www.instagram.com/zavoddpm/?igshid=1hpuwhwl9q3ni" class="instagram" target="_blank" rel="nofollow" title="Instagram">
                                                <img src="img/instagram.png" width="40" height="40" alt="Instagram">
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-6 col-md-12 col-sm-4 col-sm-offset-2">
                            <div class="title_hd fw-bold">
                                <span>Наши контакты</span>
                            </div>
                            <div class="info">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="inner-table-block p-block">
                                            <div class="phone with_dropdown big">
                                                <i class="svg inline svg-inline-phone footer_phone_color" aria-hidden="true">
                                                    <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 14 14">
                                                        <path class="pcls-1" d="M14,11.052a0.5,0.5,0,0,0-.03-0.209,1.758,1.758,0,0,0-.756-0.527C12.65,10,12.073,9.69,11.515,9.363a2.047,2.047,0,0,0-.886-0.457c-0.607,0-1.493,1.8-2.031,1.8a2.138,2.138,0,0,1-.856-0.388A9.894,9.894,0,0,1,3.672,6.253,2.134,2.134,0,0,1,3.283,5.4c0-.536,1.8-1.421,1.8-2.027a2.045,2.045,0,0,0-.458-0.885C4.3,1.932,3.99,1.355,3.672.789A1.755,1.755,0,0,0,3.144.034,0.5,0.5,0,0,0,2.935,0,4.427,4.427,0,0,0,1.551.312,2.62,2.62,0,0,0,.5,1.524,3.789,3.789,0,0,0-.011,3.372a7.644,7.644,0,0,0,.687,2.6A9.291,9.291,0,0,0,1.5,7.714a16.783,16.783,0,0,0,4.778,4.769,9.283,9.283,0,0,0,1.742.825,7.673,7.673,0,0,0,2.608.686,3.805,3.805,0,0,0,1.851-.507,2.62,2.62,0,0,0,1.214-1.052A4.418,4.418,0,0,0,14,11.052Z"/>
                                                    </svg>
                                                </i>
                                                <a href="tel:+78632098451" class="footer_zphone" > 8(863)209-84-51 </a>
                                            </div>
                                            <div class="schedule fw-lighter fs-6">
                                                <p class="special-footer-p-1">Пн. – Пт.: с 9:00 до 18:00</p>
                                                <p class="special-footer-p-2">Прием заказов без выходных</p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-12">
                                        <div class="address blocks">
                                            <i class="svg inline svg-inline-phone footer_phone_color" aria-hidden="true">
                                                <svg xmlns="http://www.w3.org/2000/svg" width="13" height="16" viewBox="0 0 13 16">
                                                    <path data-name="Ellipse 74 copy" class="cls-1" d="M763.9,42.916h0.03L759,49h-1l-4.933-6.084h0.03a6.262,6.262,0,0,1-1.1-3.541,6.5,6.5,0,0,1,13,0A6.262,6.262,0,0,1,763.9,42.916ZM758.5,35a4.5,4.5,0,0,0-3.741,7h-0.012l3.542,4.447h0.422L762.289,42H762.24A4.5,4.5,0,0,0,758.5,35Zm0,6a1.5,1.5,0,1,1,1.5-1.5A1.5,1.5,0,0,1,758.5,41Z" transform="translate(-752 -33)"></path>
                                                </svg>
                                            </i>
                                            <a class="footer_zphone" >ОТДЕЛ ПРОДАЖ: 344038, г.</a>
                                        </div>
                                        <div class="schedule">
                                            <p class="special-footer-address-1">Ростов-на-Дону, ул.</p>
                                            <p class="special-footer-address-2">Турмалиновская, 110</p>
                                        </div>
                                    </div>
                                    <div class="col-md-12">
                                        <div class="address blocks">
                                            <i class="svg inline svg-inline-phone footer_phone_color" aria-hidden="true">
                                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="13" viewBox="0 0 16 13">
                                                    <path class="ecls-1" d="M14,13H2a2,2,0,0,1-2-2V2A2,2,0,0,1,2,0H14a2,2,0,0,1,2,2v9A2,2,0,0,1,14,13ZM3.534,2L8.015,6.482,12.5,2H3.534ZM14,3.5L8.827,8.671a1.047,1.047,0,0,1-.812.3,1.047,1.047,0,0,1-.811-0.3L2,3.467V11H14V3.5Z"></path>
                                                </svg>
                                            </i>
                                            <a href="mailto:zavod.dpm@yandex.ru" class="footer_zphone">zavod.dpm@yandex.ru</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row bottom-under">
                <div class="maxwidth-theme">
                    <div class="col-md-12 outer-wrapper border-top border-secondary">
                        <div class="inner-wrapper">
                            <div class="copy-block">
                                <div class="copy">
                                    © 2022 Все права защищены.							</div>
                                <div class="print-block"></div>
                                <div id="bx-composite-banner" class="pull-right"></div>
                            </div>
                            <div class="clearfix"></div>
                        </div>
                        <div class="clearfix"></div>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <script src="js/bootstrap.bundle.min.js"></script>
</body>
</html>