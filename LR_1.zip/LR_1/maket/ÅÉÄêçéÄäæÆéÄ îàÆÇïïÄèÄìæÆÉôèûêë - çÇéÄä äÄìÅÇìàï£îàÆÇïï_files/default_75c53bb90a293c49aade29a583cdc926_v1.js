
; /* Start:"a:4:{s:4:"full";s:101:"/bitrix/templates/aspro-landscape/components/bitrix/subscribe.edit/footer2/script.min.js?157736367593";s:6:"source";s:84:"/bitrix/templates/aspro-landscape/components/bitrix/subscribe.edit/footer2/script.js";s:3:"min";s:0:"";s:3:"map";s:0:"";}"*/
$(document).ready(function(){$("form.subscribe-form").validate({rules:{EMAIL:{email:!0}}})});
/* End */
;; /* /bitrix/templates/aspro-landscape/components/bitrix/subscribe.edit/footer2/script.min.js?157736367593*/
