<?php 
    $link = mysqli_connect("localhost", "root", "", "metalwork");
    $filterActive = isset($_GET['submit']) & !isset($_GET['sumbit']);

    if (mysqli_connect_errno())
    {
        echo "Ошибка подключения к базе данных";
        exit;
    }

    if($filterActive)
    {
        $searchText = $_GET['search-text'];

        $searchYear = $_GET['year-sales'];
        $searchPriceFrom = $_GET['price-sales-from'];
        $searchPriceTo = $_GET['price-sales-to'];

        $query = "SELECT *
                  FROM sales
                  INNER JOIN sales_log on sales.Id_sales_log = sales_log.Id
                  WHERE 
                  sales.Customer_name LIKE '% . $searchText . %' OR
                  sales.Customer_address LIKE '% . $searchText . %' OR
                  sales.Outlet LIKE '% . $searchText . %' OR
                  sales.Price LIKE '% . $searchText . %' OR
                  sales_log.Year LIKE '% . $searchText . %' AND
                  sales_log.Year = " . $searchYear . " AND
                  sales.Price >= " . $searchPriceFrom . " AND
                  sales.Price <= " . $searchPriceTo . "
                  ";


    }
    else
    {
        $query = "SELECT *
                  FROM sales
                  INNER JOIN sales_log on sales.Id_sales_log = sales_log.Id";
    }

    $SalesInfo = mysqli_fetch_all(mysqli_query($link, $query), MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Журнал учета продаж</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/sales.css">
</head>
<body>
    <header>
        <div class="container">
            <div class="row">
                <div class="col-12 page-title">
                    <h1 class="d-flex justify-content-center">Журнал учета продаж</h1>
                    
                </div>
            </div>
            <form action="sales.php?go" method="get">
                <div class="container">
                    <div class="row">
                        <div class="col-3"></div>
                        <div class="col-6">
                                <div class="search">
                                    <input name="search-text" type="text" class="search-field" placeholder="Введите запрос" value = "<?php if ($filterActive) echo $_GET['search-text'] ?>">
                                    <button class="search-button" type="submit" name="submit">
                                        <img src="img/loupe.png" alt="поиск">
                                    </button>
                                </div>
                            <div class="fileture">
                                <div class="fileture-title">
                                    <button class="fileture-title">Расширенный поиск</button> 
                                </div>
                                <div class="container hidden">
                                    <div class="row params">
                                        <div class="col-4">
                                            <div class="param-year">
                                                    <div class="year-p">
                                                        <p class="year-sales-p">Год продажи:</p>
                                                    </div>
                                                    <select class="year-sales" name="year-sales">
                                                        <option <?php if ($filterActive) if ($searchYear == "") echo "selected"; ?> value = "">Все года</option>
                                                        <option <?php if ($filterActive) if ($searchYear == "2016") echo "selected"; ?> value = "2016">2016</option>
                                                        <option <?php if ($filterActive) if ($searchYear == "2017") echo "selected"; ?> value = "2017">2017</option>
                                                        <option <?php if ($filterActive) if ($searchYear == "2018") echo "selected"; ?> value = "2018">2018</option>
                                                        <option <?php if ($filterActive) if ($searchYear == "2019") echo "selected"; ?> value = "2019">2019</option>
                                                        <option <?php if ($filterActive) if ($searchYear == "2020") echo "selected"; ?> value = "2020">2020</option>
                                                    </select>
                                            </div>  
                                        </div>
                                        <div class="col-4">
                                            <div class="param-price">
                                                <div class="price">
                                                    <p class="price-sales">Цена от:</p>
                                                    <input type="number" class="price-sales-i" value="<?php if ($filterActive) echo $_GET['price-sales-from'] ?>" name="price-sales-from">
                                                </div>
                                                <div class="price">
                                                    <p class="price-sales">Цена до:</p>
                                                    <input type="number" class="price-sales-i" value="<?php if ($filterActive) echo $_GET['price-sales-to'] ?>" name="price-sales-to">
                                                </div>
                                            </div>  
                                        </div>
                                        <div class="col-4">
                                            <div class="clear">
                                                <input type="submit" name="clear" class="clear" value="Сбросить">
                                            </div>
                                            <div class="clear">
                                                <input type="submit" name="submit" class="submit" value="Применить">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-3"></div>
                    </div>
                </div>
            </form>

            <div class="row border-2 border-bottom border-top border-primary bgc">
                <div class="col-3 d-flex justify-content-center">
                    <div class="title">
                        <h5>Информация о покупателе</h5>
                    </div>
                </div>
                <div class="col-2 d-flex justify-content-center">
                    <h5>Примечание</h5>
                </div>
                <div class="col-1 d-flex justify-content-center">
                    <h5>Стоимость</h5>
                </div>
                <div class="col-2 d-flex justify-content-center">
                    <h5>Торговая точка</h5>
                </div>
                <div class="col-1 d-flex justify-content-center">
                    <h5>Год</h5>
                </div>
                <div class="col-3 d-flex justify-content-center">
                    <h5>Скан чека</h5>
                </div>
            </div>
        </div>
    </header>
        <div class="container">
            <div class="row">
                <div class="col-3">
                <div class="customer_information">
                    <?php 
                        foreach ($SalesInfo as $item)
                        {
                    ?>
                        <div class="name_n">
                            <p class="C_text"><b>Имя и фамилия:</b>
                                <?= $item['Customer_name'] ?>
                            </P>
                            <p class="C_text"><b>Адрес:</b>
                                <?= $item['Customer_address'] ?>
                            </p>
                        </div>
                    <?php 
                        }
                    ?> 
                    </div>
                </div>
                <div class="col-2">
                    <div class="note">
                        <?php 
                            foreach ($SalesInfo as $item)
                            {
                        ?>
                            <div class="note_n">
                                <p class="C_text">
                                    <?= $item['Note'] ?>
                                </P>
                            </div>
                        <?php 
                            }
                        ?> 
                    </div>
                </div>
                <div class="col-1">
                    <div class="price">
                        <?php 
                            foreach ($SalesInfo as $item)
                            {
                        ?>
                            <div class="price_n">
                                <p class="N_text">
                                    <?= $item['Price'] ?>
                                </P>
                            </div>
                        <?php 
                            }
                        ?> 
                    </div>
                </div>
                <div class="col-2">
                    <div class="outlet">
                        <?php 
                            foreach ($SalesInfo as $item)
                            {
                        ?>
                            <div class="outlet_n">
                                <p class="N_text">
                                    <?= $item['Outlet'] ?>
                                </P>
                            </div>
                        <?php 
                            }
                        ?> 
                    </div>
                </div>
                <div class="col-1">
                    <div class="year">
                        <?php 
                            foreach ($SalesInfo as $item)
                            {
                        ?>
                            <div class="outlet_n">
                                <p class="N_text">
                                    <?= $item['Year'] ?>
                                </P>
                            </div>
                        <?php 
                            }
                        ?> 
                    </div>
                </div>
                <div class="col-3">
                    <?php 
                        foreach ($SalesInfo as $item)
                        {
                    ?>
                    <div class="scan">
                        <div class="receipt_scan">
                            <img src="img/metalwork(cheki)/<?= $item['Receipt_scan'] ?>" alt="скан чека">
                        </div>
                    </div>
                    <?php 
                        }
                    ?> 
                </div>
            </div>
        </div>
</body>
</html>